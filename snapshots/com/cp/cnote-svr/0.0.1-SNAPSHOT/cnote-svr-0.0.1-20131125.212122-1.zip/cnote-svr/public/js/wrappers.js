define('modernizr', function() {
  return window.Modernizr;
});